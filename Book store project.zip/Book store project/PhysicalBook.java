public class PhysicalBook extends Book {
    public PhysicalBook(String isbn, String title, String author, double price, int stockQty) {
        super(isbn, title, author, price, stockQty);
    }

    @Override
    public String getDetails() {
        return "Physical Book: " + title + " by " + author;
    }
}

