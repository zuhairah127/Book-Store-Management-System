public abstract class PaymentMethod {
    protected String methodType;

    public PaymentMethod(String methodType) {
        this.methodType = methodType;
    }

    public abstract void confirmPayment(double amount);
}
