public class Transaction {
    private double amount;
    private PaymentMethod payment;

    public Transaction(double amount, PaymentMethod payment) {
        this.amount = amount;
        this.payment = payment;
    }

    public void processPayment() {
        payment.confirmPayment(amount);
    }
}

