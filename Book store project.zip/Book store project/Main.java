import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Customer c = new Customer("C001", "Ali", "ali@email.com");
        c.login();

        // Sample book list
        Book b1 = new Ebook("ISBN123", "Java Basics", "Liang", 50.00, 10);
        Book b2 = new PhysicalBook("ISBN456", "Clean Code", "Martin", 80.00, 5);

        Order order = new Order(c);
        order.addBook(b1, 1);
        order.addBook(b2, 2);

        order.displayOrder();

        // Choose payment
        PaymentMethod payment = new CashPayment(); // or new OnlinePayment();
        Transaction txn = new Transaction(order.calculateTotal(), payment);
        txn.processPayment();

        c.logout();

        Order[] orders = new Order[100];
        int orderCount = 0;
        Book[] books = new Book[100];
        int bookCount = 0;
        Customer[] customers = new Customer[100];
        int custCount = 0;

        orders[orderCount++] = order;
        books[bookCount++] = b1;
        books[bookCount++] = b2;
        customers[custCount++] = c;


        ReportGenerator.dailyReport(orders, orderCount);
        ReportGenerator.bestSellingBooks(orders, orderCount, books, bookCount);
        ReportGenerator.topCustomers(customers, custCount, orders, orderCount);

    }
}
