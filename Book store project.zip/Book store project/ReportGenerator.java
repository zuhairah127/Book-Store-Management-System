public interface ReportGenerator {
    void generateSalesReport(Order[] orders);

    // DAILY REPORT: Total revenue of the day
    public static void dailyReport(Order[] orders, int orderCount) {
        System.out.println("\n--- Daily Sales Report ---");
        double total = 0;
        for (int i = 0; i < orderCount; i++) {
            total += orders[i].calculateTotal();
        }
        System.out.printf("Total Sales Today: RM%.2f%n", total);
    }

    // BEST-SELLING BOOKS REPORT
    public static void bestSellingBooks(Order[] orders, int orderCount, Book[] books, int bookCount) {
        System.out.println("\n--- Best-Selling Books ---");
        int[] sales = new int[bookCount];

        // count quantity sold per book
        for (int i = 0; i < orderCount; i++) {
            Order o = orders[i];
            Book[] items = o.getBooks();
            int[] qtys = o.getQuantities();
            int itemCount = o.getItemCount();

            for (int j = 0; j < itemCount; j++) {
                for (int k = 0; k < bookCount; k++) {
                    if (items[j].getTitle().equals(books[k].getTitle())) {
                        sales[k] += qtys[j];
                    }
                }
            }
        }

        // display sales
        for (int i = 0; i < bookCount; i++) {
            System.out.println(books[i].getTitle() + ": " + sales[i] + " sold");
        }
    }

    // TOP CUSTOMERS (by number of orders)
    public static void topCustomers(Customer[] customers, int custCount, Order[] orders, int orderCount) {
        System.out.println("\n--- Top Customers (by orders) ---");
        int[] counts = new int[custCount];

        for (int i = 0; i < orderCount; i++) {
            Order o = orders[i];
            for (int j = 0; j < custCount; j++) {
                if (customers[j].name.equals(o.getCustomer().name)) {
                    counts[j]++;
                }
            }
        }

        for (int i = 0; i < custCount; i++) {
            System.out.println(customers[i].name + " → " + counts[i] + " orders");
        }
    }
}
