public class Order {
    private Book[] books = new Book[10];
    private int[] quantities = new int[10];
    private int count = 0;

    public void addBook(Book book, int qty) {
        books[count] = book;
        quantities[count] = qty;
        book.updateStock(-qty);
        count++;
    }

    public double calculateTotal() {
        double total = 0;
        for (int i = 0; i < count; i++) {
            total += books[i].getPrice() * quantities[i];
        }
        return total;
    }

    public void displayOrder() {
        for (int i = 0; i < count; i++) {
            System.out.println(books[i].getDetails() + " x" + quantities[i]);
        }
        System.out.printf("Total: RM%.2f%n", calculateTotal());
    }

    private Customer customer;

    public Order(Customer customer) {
        this.customer = customer;
    }

    public Book[] getBooks() { return books; }
    public int[] getQuantities() { return quantities; }
    public int getItemCount() { return count; }
    public Customer getCustomer() { return customer; }

}
