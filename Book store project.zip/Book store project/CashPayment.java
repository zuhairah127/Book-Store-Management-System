public class CashPayment extends PaymentMethod {
    public CashPayment() {
        super("Cash");
    }

    @Override
    public void confirmPayment(double amount) {
        System.out.println("Cash payment of RM" + amount + " confirmed.");
    }
}

