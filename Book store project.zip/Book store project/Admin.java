public class Admin extends User implements ReportGenerator {

    public Admin(String id, String name, String password) {
        super(id, name, password);
    }

    @Override
    public void showMenu() {
        System.out.println("Welcome Admin " + name);
        System.out.println("1. View Reports");
        System.out.println("2. Exit");
    }

    @Override
    public void generateSalesReport(Order[] orders) {
        System.out.println("===== SALES REPORT =====");
        double totalSales = 0;

        for (Order order : orders) {
            if (order != null) {
                order.displayOrder();
                totalSales += order.calculateTotal(); // ✅ correct method
            }
        }

        System.out.printf("Total Sales: RM%.2f\n", totalSales);
        System.out.println("========================");
    }
}

    

