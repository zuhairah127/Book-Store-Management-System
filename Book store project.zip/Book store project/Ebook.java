public class Ebook extends Book {
    public Ebook(String isbn, String title, String author, double price, int stockQty) {
        super(isbn, title, author, price, stockQty);
    }

    @Override
    public String getDetails() {
        return "E-Book: " + title + " by " + author;
    }
}

