public class Customer extends User {
    public Customer(String id, String name, String email) {
        super(id, name, email);
    }

    @Override
    public void login() {
        System.out.println("Customer " + name + " logged in.");
    }

    @Override
    public void logout() {
        System.out.println("Customer " + name + " logged out.");
    }
}


