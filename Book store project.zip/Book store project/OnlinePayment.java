public class OnlinePayment extends PaymentMethod {
    public OnlinePayment() {
        super("Online");
    }

    @Override
    public void confirmPayment(double amount) {
        System.out.println("Online payment of RM" + amount + " confirmed.");
    }
}

