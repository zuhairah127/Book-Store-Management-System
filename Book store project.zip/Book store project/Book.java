public abstract class Book {
    protected String isbn;
    protected String title;
    protected String author;
    protected double price;
    protected int stockQty;

    public Book(String isbn, String title, String author, double price, int stockQty) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.price = price;
        this.stockQty = stockQty;
    }

    public abstract String getDetails();

    public void updateStock(int quantity) {
        this.stockQty += quantity;
    }

    public int getStockQty() {
        return stockQty;
    }

    public double getPrice() {
        return price;
    }

    public String getTitle() {
        return title;
    }
}
